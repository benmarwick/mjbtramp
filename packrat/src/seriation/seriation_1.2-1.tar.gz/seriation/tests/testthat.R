library("testthat")

library("seriation")
test_check("seriation")
