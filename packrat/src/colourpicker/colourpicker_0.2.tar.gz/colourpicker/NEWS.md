# colourpicker 0.2

2016-09-06

- Fix vignette source to have an output (CRAN reminded me to do this) 

# colourpicker 0.1.1

2016-08-15

- upgrade to newer version of JS library that fixed bugs with new jquery
- add `runExample()` function to run the example shiny app


# colourpicker 0.1

2016-08-11

- initial version (mostly copied over from `shinyjs` package)
