### R code from vignette source 'Theory.Rnw'

###################################################
### code chunk number 1: preliminaries
###################################################
options(width=65,digits=5)
#library(lme4)


