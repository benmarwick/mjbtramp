"psych" <-
function () {} # a dummy function to make it appear in the help menu

"sim" <-
function() {}  #another dummy function to make the help easier to use

