library(testthat)
library(lmPerm)

test_check("lmPerm")
