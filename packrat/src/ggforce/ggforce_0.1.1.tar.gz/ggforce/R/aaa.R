globalVariables(
    c(
        '.'
    )
)
