# CHANGES IN bookdown VERSION 0.2 (unreleased)

## BUG FIXES

- Figures are not correctly numbered in Word output using the `bookdown::word_document2()` format (thanks, @byzheng, #158).

# CHANGES IN bookdown VERSION 0.1

## NEW FEATURES

- Initial CRAN release.
