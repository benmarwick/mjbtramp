library(testthat)
library("TestExclusion")

test_check("TestExclusion")
