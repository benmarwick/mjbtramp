"ES.h" <-
function (p1, p2) 
{
    2 * asin(sqrt(p1)) - 2 * asin(sqrt(p2))
}
