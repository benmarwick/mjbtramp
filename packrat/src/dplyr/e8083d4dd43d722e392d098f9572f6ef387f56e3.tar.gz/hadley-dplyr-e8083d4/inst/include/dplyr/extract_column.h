#ifndef dplyr_dplyr_extract_column_H
#define dplyr_dplyr_extract_column_H

namespace dplyr {

  Symbol extract_column(SEXP, const Environment&);

}

#endif // #ifndef dplyr_dplyr_extract_column_H
