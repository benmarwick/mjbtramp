library(testthat)
library(corrr)

test_check("corrr")
