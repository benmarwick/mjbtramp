#' @importFrom magrittr "%>%"
#' @importFrom magrittr "%<>%"
#' @importFrom stats "dist"
#' @import dplyr
NULL